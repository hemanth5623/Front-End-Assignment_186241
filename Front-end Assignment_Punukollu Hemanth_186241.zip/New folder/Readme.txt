Steps to view the project:
1. Download the zip file and extract the folders.
2. Open the html file with browser to view the interface.
